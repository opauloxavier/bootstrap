<?php
	$username = $_POST['name'];
	echo $name;
?>